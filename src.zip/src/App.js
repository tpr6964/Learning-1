import React, {Component} from 'react';
import StackNav from './src/navigation/StackNav';


export default class App extends Component{
    render(){
        return (
          <StackNav />
        );
    }
} 