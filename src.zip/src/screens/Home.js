import React, {Component} from 'react';
import {View, Text, StyleSheet, Button, TextInput} from 'react-native';


export default class Home extends Component{
    render(){
        return(
            <View style={styles.container}>
                <Text>Enter Your Name</Text>
                <TextInput style={styles.inputtxt} />

                <Button
                    title="Go to Details"
                    onPress={() => this.props.navigation.navigate('Details')}
                />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex:1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    inputtxt:{
        margin: 20,
        width: 300,
        height: 30,
        borderWidth: 1,
        borderColor: 'red',
        borderRadius: 6,
        paddingHorizontal: 10,
    },
});